HOM AGROS Website
=================

Files:
- index.html: responsive one-page website
- assets/hom-agros-logo.png: original HOM AGROS logo

WhatsApp ordering:
+91 8432219516

Publish for free using GitHub Pages:
1. Create/sign in to a GitHub account at https://github.com/
2. Create a NEW PUBLIC repository, for example: hom-agros-website
3. Upload index.html and the entire assets folder (keep the same structure).
4. Open repository Settings -> Pages.
5. Under Build and deployment, select Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait for deployment; GitHub Pages will show the live website URL on the Pages screen.

Official instructions:
https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

Notes:
- Garlic and ginger powder prices are set to “Price on request” because prices were not supplied.
- The website uses externally hosted product photos, so an internet connection is needed to display those photos.
- The website is a catalogue with WhatsApp links, not an online payment/cart system.
